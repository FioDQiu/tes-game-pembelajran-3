// EduPlay Arena - Standalone Zero-Dependency Local Web Server
// Jalankan dengan: node server.js
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = __dirname;

const MIME_TYPES = {
    '.html': 'text/html; charset=UTF-8',
    '.css': 'text/css; charset=UTF-8',
    '.js': 'application/javascript; charset=UTF-8',
    '.json': 'application/json; charset=UTF-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
};

function getLocalIpAddresses() {
    const interfaces = os.networkInterfaces();
    const ips = [];
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal) {
                ips.push(iface.address);
            }
        }
    }
    return ips;
}

const server = http.createServer((req, res) => {
    let reqPath = decodeURI(req.url.split('?')[0]);
    if (reqPath === '/' || reqPath === '') {
        reqPath = '/index.html';
    }

    let filePath = path.join(PUBLIC_DIR, reqPath);

    // If file doesn't exist directly, check fallback to index (13).html
    if (!fs.existsSync(filePath)) {
        if (fs.existsSync(path.join(PUBLIC_DIR, 'index (13).html'))) {
            filePath = path.join(PUBLIC_DIR, 'index (13).html');
        } else {
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            res.end('404 Not Found');
            return;
        }
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.writeHead(500, { 'Content-Type': 'text/plain' });
            res.end('500 Internal Server Error');
            return;
        }
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(data);
    });
});

server.listen(PORT, '0.0.0.0', () => {
    const ips = getLocalIpAddresses();
    console.log('================================================================');
    console.log('🎮 EDUPLAY ARENA - SERVER MULTI-USER AKTIF!');
    console.log('================================================================');
    console.log(`💻 Buka di Laptop Guru : http://localhost:${PORT}`);
    if (ips.length > 0) {
        ips.forEach(ip => {
            console.log(`📱 Buka di HP / Tablet Siswa : http://${ip}:${PORT}`);
        });
    }
    console.log('================================================================');
    console.log('Siswa dan Guru cukup berada di jaringan Wi-Fi yang sama');
    console.log('atau buka langsung file HTML via browser.');
    console.log('================================================================');
});

